// Write a program to get four integer variables as input 
// and do the check whether each of them is divisible by 2 and 3 or it is divisible by 5. 
// If it is true and if more than one value is satisfying the conditio,
// then select the largest of the numbers which satisfy the condition 
// and pass that value by reference to a function refer, 
// multiply it by 10 and print the variable value in the main.



#include <stdio.h>

void mul10(int *max)
{
    *max = *max * 10;
}

int divisible(int);

int main()
{
    int a, b, c, d, max = -1;
    // printf("Enter four numbers: a b c d :   ");
    scanf("%d %d %d %d", &a, &b, &c, &d);
    
    if ((a % 2 == 0 && a % 3 == 0) || a % 5 == 0)
    {
        if (a > max)
        {
            max = a;
        }
    }
    if ((b % 2 == 0 && b % 3 == 0) || b % 5 == 0)
    {
        if (b > max)
        {
            max = b;
        }
    }
    if ((c % 2 == 0 && c % 3 == 0) || c % 5 == 0)
    {
        if (c > max)
        {
            max = c;
        }
    }
    if ((d % 2 == 0 && d % 3 == 0) || d % 5 == 0)
    {
        if (d > max)
        {
            max = d;
        }
    }

    // if (max == -1)
    // {
    //     printf("No any number satisfied divisibility.");
    // }
    // else
    // {
    //     mul10(&max);
    //     printf("The required output is: %d", max);
    // }
    
    if (max == -1)
    {
        
    }
    else
    {
        mul10(&max);
        printf("%d", max);
    }
    return 0;
}
