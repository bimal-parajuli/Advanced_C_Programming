#include <stdio.h>
void display(int *);

int main()
{
    int n, temp, temp1;
    printf("Enter the number of integers you want to input.\n(should be even positive integer):");
    while (1)
    {
        scanf("%d", &n);                      //get number of entries in the matrix(should be a positive even number).
        if (n > 0 && n % 2 == 0)
        {
            break;
        }
        else
        {
            printf("Re-enter a positive even integer.");
        }
    }

    int myarray[25];
    int *ptr = myarray;
    printf("Now enter the %d integers.\n", n);
    for (int i = 0; i < 25; i++)
    {
        if (i < (n >> 1))                   //Used right shift operator to divide by 2.
        {
            scanf("%d", (ptr + i));         //upto n/2 numbers, take input from user and insert into matrix.
        }

        if ((i >= (n >> 1)) && (i < (25 - (n >> 1))))
        {
            *(ptr + i) = 0;                //from n/2 to last n/2 numbers, put directly zero.
        }

        if (i >= (25 - (n >> 1)))
        {
            scanf("%d", (ptr + i));       //in last n/2 numbers, take unput from user and insert into matrix.
        }
    }

    display(myarray);
    return 0;
}

void display(int *p)
{
    int counter = 0;
    printf("\nFinally, The matrix is:\n");
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            int x = p[counter];
                                         //making the matrix output properly aligned in straight columns.
            if (x > 999)              
            {
                printf("%d ", x);
            }
            else if (x > 99)
            {
                printf("%d  ", x);
            }
            else if (x > 9)
            {
                printf("%d   ", x);
            }
            else
            {
                printf("%d    ", x);
            }
            counter++;
        }
        printf("\n");
    }
}
