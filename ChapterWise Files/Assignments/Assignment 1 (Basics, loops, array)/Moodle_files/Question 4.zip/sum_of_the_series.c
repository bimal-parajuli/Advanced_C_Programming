//Write a program to print the output (sum) of the series,
//1 + x + 2x + 3x... and 
//1 + x/2 + 2x/3 + 3x/4.. 
//(Use double for output) till n numbers, where n is coefficient of x.

#include<stdio.h>
int main()
{
    int n, x;
    scanf ("%d %d", &n, &x);
    
    
    double sum1=1, sum2=1;
    for (int i=0; i < n; i++)
    {
        sum1 += ( double )( i * x ) ;
    }
    printf("%lf\n", sum1);
    
    
    for(int i=0; i < n; i++)
    {
        sum2 += ( (double)(i * x) / (i+1) );
    }
    printf("%lf\n", sum2);
    return 0;
}

