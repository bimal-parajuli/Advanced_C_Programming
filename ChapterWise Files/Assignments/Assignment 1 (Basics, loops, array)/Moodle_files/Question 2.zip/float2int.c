#include<stdio.h>
int main()
{
    float x;  
    int y;
    
    scanf("%f", &x);           //get float input from user.
    y = (int) (x + 0.5);       //convert into nearest int by adding 0.5 and removing the trailing decimal part.
    
    printf("%d", y);           //display the resultant integer.
    return 0;
}