                                                // Try to print the following pattern using loops:
                                                
                                                // 0 
                                                
                                                // 1 0
                                                
                                                // 0 1 0
                                                
                                                // 1 0 1 0
                                                
                                                // 0 1 0 1 0
                                                
                                                // ….
                                                
                                                // For n number of lines.
                                                
                                                // Eg. For n=1,
                                                
                                                // 0
                                                
                                                // For n=3,
                                                
                                                // 0
                                                
                                                // 1 0
                                                
                                                // 0 1 0

#include<stdio.h>
int main()
{
    int choice, counter=1;
    scanf("%d", &choice);
    
    for(int i=1; i<=choice; i++)
    {
        
        for (int j=1; j<=i; j++)
        {
            if( (counter+i) & 1 )              //checking if its odd by bit manipulation.
            {
                printf("%d ", 1);
            }
            else
            {
                printf("%d ", 0);
            }
            counter++;
            
        }
        counter=1;
        printf("\n");
    }
    return 0;
}